import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Login } from '../../models/login';
import { AuthServiceService } from '../../services/auth-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
})
export class LoginComponent implements OnInit {
  login: Login = new Login();
  constructor(
    private authService: AuthServiceService,
    private router: Router
  ) {}

  loginSubmit() {
    const user: any = {
      email: this.login.email,
      password: this.login.password,
    };
    this.authService.loginUser(user).subscribe(
      (res) => {
        console.log('inside login login');
        this.router.navigate(['/dashboard']);
        localStorage.setItem('token', res.token);
      },
      (err) => {
        console.log(JSON.stringify(err));
      }
    );
  }

  ngOnInit(): void {}
}
