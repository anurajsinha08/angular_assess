import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Register } from '../../models/register';
import { AuthServiceService } from '../../services/auth-service.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css'],
})
export class RegisterComponent implements OnInit {
  register: Register = new Register();

  constructor(
    private authService: AuthServiceService,
    private router: Router
  ) {}

  registerSubmit() {
    const user: any = {
      name: this.register.name,
      email: this.register.email,
      password: this.register.password,
    };

    this.authService.registerUser(user).subscribe(
      (res) => {
        this.router.navigate(['/dashboard']);
        localStorage.setItem('token', res.token);
      },
      (err) => {}
    );
  }

  ngOnInit(): void {}
}
