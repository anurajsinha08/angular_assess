import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Register } from 'src/app/auth/models/register';
import { AuthServiceService } from 'src/app/auth/services/auth-service.service';
import { CreateProfile } from 'src/app/profile/models/create-profile';
import { CreateProfileService } from 'src/app/profile/services/create-profile.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
})
export class DashboardComponent implements OnInit {
  register: Register;
  profile: CreateProfile;

  constructor(
    private authService: AuthServiceService,
    private getProfile: CreateProfileService
  ) {}

  ngOnInit(): void {
    this.authService.loadUser().subscribe(
      (res) => {
        localStorage.setItem('user', JSON.stringify(res));
        this.register = res;
      },
      (err) => console.log(err)
    );

    this.getProfile.getProfile().subscribe(
      (res) => {
        this.profile = res;
        localStorage.setItem('profile', JSON.stringify(res));
      },
      (err) => console.log(err)
    );
  }
}
