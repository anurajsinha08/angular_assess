import { Component, OnInit } from '@angular/core';
import { CreateProfileService } from 'src/app/profile/services/create-profile.service';
import { Profile } from '../../models/profile';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css'],
})
export class ProfileComponent implements OnInit {
  profile: Profile;
  constructor(private getProfile: CreateProfileService) {}

  ngOnInit(): void {
    this.getProfile.getProfile().subscribe(
      (res) => {
        this.profile = res;
        localStorage.setItem('profile', JSON.stringify(res));
      },
      (err) => console.log(err)
    );
  }
}
