export class User {
  _id: string;
  name: string;
  avatar: string;
}

export class Experience {
  company: String;
  title: String;
  location: String;
  from: String;
  to: String;
  current: Boolean;
  description: String;
}

export class Education {
  school: String;
  degree: String;
  fieldofstudy: String;
  from: Date;
  to: Date;
  current: boolean;
  description: String;
}

export class Profile {
  user: User;
  experience: Experience;
  education: Education;
  company: string;
  website: string;
  location: string;
  status: string;
  skills: string;
  bio: string;
  githubusername: string;
  social: any;
  twitter: string;
  facebook: string;
  linkedin: string;
  youtube: string;
  instagram: string;
}
