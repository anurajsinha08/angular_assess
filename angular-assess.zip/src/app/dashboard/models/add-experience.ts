export class AddExperience {
  company: String;
  title: String;
  location: String;
  from: String;
  to: String;
  current: Boolean;
  description: String;
}
