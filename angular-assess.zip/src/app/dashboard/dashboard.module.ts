import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DashboardRoutingModule } from './dashboard-routing.module';
import { DashboardComponent } from './components/dashboard/dashboard.component';
import { httpInterceptorProviders } from '../core/interceptor';
import { AuthServiceService } from '../auth/services/auth-service.service';
import { HttpClientModule } from '@angular/common/http';
import { CreateProfileService } from '../profile/services/create-profile.service';
import { ProfileComponent } from './components/profile/profile.component';
import { ProfileAboutComponent } from './components/profile-about/profile-about.component';
import { ProfileEducationComponent } from './components/profile-education/profile-education.component';
import { ProfileExperienceComponent } from './components/profile-experience/profile-experience.component';
import { ProfileTopComponent } from './components/profile-top/profile-top.component';

@NgModule({
  declarations: [DashboardComponent, ProfileComponent, ProfileAboutComponent, ProfileEducationComponent, ProfileExperienceComponent, ProfileTopComponent],
  providers: [
    httpInterceptorProviders,
    AuthServiceService,
    CreateProfileService,
  ],
  imports: [CommonModule, HttpClientModule, DashboardRoutingModule],
})
export class DashboardModule {}
