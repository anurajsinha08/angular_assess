import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProfileRoutingModule } from './profile-routing.module';
import { httpInterceptorProviders } from '../core/interceptor';
import { CreateProfileComponent } from './components/create-profile/create-profile.component';
import { CreateProfileService } from './services/create-profile.service';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [CreateProfileComponent],
  providers: [httpInterceptorProviders, CreateProfileService],
  imports: [CommonModule, FormsModule, HttpClientModule, ProfileRoutingModule],
})
export class ProfileModule {}
