import { Component, OnInit } from '@angular/core';
import { CreateProfile } from '../../models/create-profile';
import { CreateProfileService } from '../../services/create-profile.service';

@Component({
  selector: 'app-create-profile',
  templateUrl: './create-profile.component.html',
  styleUrls: ['./create-profile.component.css'],
})
export class CreateProfileComponent implements OnInit {
  createProfile: CreateProfile = new CreateProfile();

  constructor(private createProfileService: CreateProfileService) {}

  createProfileSubmit() {
    this.createProfileService.createProfile(this.createProfile).subscribe(
      (res) => {
        console.log('succes');
      },
      (err) => {
        console.log(JSON.stringify(err));
      }
    );
  }

  ngOnInit(): void {}
}
