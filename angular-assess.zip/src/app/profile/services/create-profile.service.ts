import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class CreateProfileService {
  constructor(private httpClient: HttpClient) {}

  createProfile(data: any): Observable<any> {
    return this.httpClient.post('/api/profile', data);
  }

  getProfile(): Observable<any> {
    return this.httpClient.get('/api/profile/me');
  }
}
