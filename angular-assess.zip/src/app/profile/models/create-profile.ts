export class CreateProfile {
  company: string;
  website: string;
  location: string;
  status: string;
  skills: string;
  bio: string;
  githubusername: string;
  twitter: string;
  facebook: string;
  linkedin: string;
  youtube: string;
  instagram: string;
}
